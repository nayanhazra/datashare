package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by tejwania on 22/06/2017.
 */
public class MenuItem {
    private String assetClassName;
    private String top20 = "Top 20% Losers";
    private String top10 = "Top 10% Losers";
    private String top5 = "Top 5% Losers";

    public MenuItem(String assetClassName) {
        this.assetClassName = assetClassName;
    }

    public String getAssetClassName() {
        return assetClassName;
    }

    public String getTop20() {
        return top20;
    }

    public String getTop10() {
        return top10;
    }

    public String getTop5() {
        return top5;
    }
}
