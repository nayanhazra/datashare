package model;

/**
 * Created by tejwania on 23/06/2017.
 */
public class GridItem {
    private String clientId;
    private String clientName;
    private double deviation;

    public GridItem(String clientId, String clientName, double deviation) {
        this.clientId = clientId;
        this.clientName = clientName;
        this.deviation = deviation;
    }

    public String getClientId() {
        return clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public double getDeviation() {
        return deviation;
    }
}
