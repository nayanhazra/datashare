package model;

/**
 * Created by tejwania on 23/06/2017.
 */
public class ChartItem {
    private String tradeDate;
    private String tradeValue;

    public ChartItem(String tradeDate, String tradeValue) {
        this.tradeDate = tradeDate;
        this.tradeValue = tradeValue;
    }

    public String getTradeDate() {
        return tradeDate;
    }

    public String getTradeValue() {
        return tradeValue;
    }
}
