package hello;

import model.ChartItem;
import model.GridItem;
import model.MenuItem;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by tejwania on 22/06/2017.
 */
@Controller
public class ViewController {
    @RequestMapping(value = "/wel", method = RequestMethod.GET)
    public String homepage() {
        return "welcome";
    }

    @RequestMapping(value = "/men", method = RequestMethod.GET)
    public String menu() {
        return "menu";
    }

    @RequestMapping(value = "/accordion", method = RequestMethod.GET)
    public String accordion() {
        return "accordion";
    }

    @RequestMapping(value = "/customer", method = RequestMethod.GET)
    public String customer() {
        return "customer";
    }

    @RequestMapping(value = "/customer_new", method = RequestMethod.GET)
    public String customer_new() {
        return "customer_new";
    }

    @RequestMapping(value = "/customer_reco_log", method = RequestMethod.GET)
    public String customer_reco_log() {
        return "customer_reco_log";
    }
    @RequestMapping(value = "/client_table", method = RequestMethod.GET)
    public String client_table() {
        return "client_table";
    }
    @RequestMapping(value = "/recommendation", method = RequestMethod.GET)
    public String recommendation() {
        return "recommendation";
    }

    @RequestMapping(value = "/griddata", method = RequestMethod.GET)
    public ResponseEntity<List<ChartItem>> griddata() {
        List<ChartItem> chart = new ArrayList<ChartItem>();
        chart.add(new ChartItem("20-JAN-2016","10"));
        chart.add(new ChartItem("21-JAN-2016","10"));
        chart.add(new ChartItem("22-JAN-2016","10"));
        chart.add(new ChartItem("23-JAN-2016","10"));
        return ResponseEntity.ok(chart);
    }

    @RequestMapping("/gridItem")
    public ResponseEntity<List<GridItem>> getMenuItems(){
        GridItem item1= new GridItem("CLI_33425","Arnold S", 23d);
        GridItem item2= new GridItem("CLI_53425","Neo Matrix", 25d);
        GridItem item3= new GridItem("CLI_9565","Forrest Gump", 33d);
        GridItem item4= new GridItem("CLI_4355","John Travolta", 56d);

        List<GridItem> gridItems = new ArrayList<>();
        gridItems.add(item1);
        gridItems.add(item2);
        gridItems.add(item3);
        gridItems.add(item4);

        //model.addAttribute("menuItems", menuItems);

        return ResponseEntity.ok(gridItems);
    }
}
