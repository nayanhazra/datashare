package hello;

import model.MenuItem;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
/**
 * Created by tejwania on 22/06/2017.
 */
@RestController
public class MenuController {

    @RequestMapping("/menuItems")
    public ResponseEntity<List<MenuItem>> getMenuItems(){
        MenuItem irs = new MenuItem("IRS");
        MenuItem fx = new MenuItem("FX");

        List<MenuItem> menuItems = new ArrayList<>();
        menuItems.add(irs);
        menuItems.add(fx);

        //model.addAttribute("menuItems", menuItems);

        return ResponseEntity.ok(menuItems);
    }
}
