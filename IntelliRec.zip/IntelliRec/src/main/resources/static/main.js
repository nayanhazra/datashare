$(document).ready(function () {
    alert('asdasd');
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/menuItems",
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {

            var ul = $('<ul>').appendTo('body');
            var json = [{"assetClassName":"IRS",
                "top20":"Top 20% Losers",
                "top10":"Top 10% Losers",
                "top5":"Top 5% Losers"},
                {"assetClassName":"FX",
                    "top20":"Top 20% Losers",
                    "top10":"Top 10% Losers",
                    "top5":"Top 5% Losers"}];

            ul.append("<div id='accordion'>");
            $(json).each(function(index, item) {
                ul.append(
                    $(document.createElement('h3')).text(item.assetClassName)
                );
                ul.append("<ul>");
                ul.append(
                    $(document.createElement('li')).text(item.top20)
                );
                ul.append("</ul>");
            });
            ul.append("</div>");

            alert('SUCCESS : ');


        },
        error: function (e) {

            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            $('#feedback').html(json);

            console.log("ERROR : ", e);
            $("#btn-search").prop("disabled", false);

        }
    });

});

