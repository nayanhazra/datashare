// var app = angular.module('demo', []);
//
//
// app.controller("Hello",["$scope","$http",
//     function($scope,$http){
//         $http.get("http://localhost:8080/menuItems")
//             .success(function(data){
//                 $scope.items = data;
//             })
//             .error(function(exp){
//                 alert(exp);
//             });
//     }]
// );


app.controller('usersController', function($scope) {
    $scope.headingTitle = "User List";
});