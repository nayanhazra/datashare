var app = angular.module('demo', ['ngRoute', 'ngResource']);
app.config(function ($routeProvider) {
    $routeProvider
        .when('/xya', {
            templateUrl: '/views/ang.html',
            controller: 'usersController'
        })
        .otherwise(
            {redirectTo: '/'}
        );
});
